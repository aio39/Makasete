// exports.http = (request, response) => {
//   response.status(200).send('Hello World!');
// };

exports.event = (event, callback) => {
  callback();
};

const vision = require('@google-cloud/vision')();

exports.http = (request, response) => {
  const uri = request.query.uri;
  if (uri == null) {
    response
      .status(400)
      .json({ error: "Must include a 'uri' query parameter." });
  }
  const image = {
    source: {
      imageUri: uri,
    },
  };
  vision
    .textDetection(image)
    .then((results) => {
      const annotations = results[0].labelAnnotations;
      const labels = annotations.map((a) => a.description);
      const resp = {
        image: uri,
        labels,
      };
      response.status(200).json(resp);
    })
    .catch((err) => {
      console.log(err);
      response.status(200).send(err);
    });
};
